Devoid and Emergency Transmission are the tracks that will play during the gameplay portion

Black Hole gets played when the player loses the game

Mission critial is for the main menu

The music_switch script I have included is for Devoid and Emergency Transmission. Attach the script to the audio source in the gameplay scene, and in the inspector change the "songs" attribute in the script to be of size two. Drag and drop each track into the slots that appear when you enter in two, and the script will automatically pick a song to play when the game starts.